import React, { createContext, useContext, useMemo, useState } from "react";
import type { CartItem, MenuItem } from "@shared/api";

export class CartService {
  private _items: CartItem[] = [];
  get items(): CartItem[] {
    return this._items;
  }

  add(item: MenuItem, qty = 1) {
    const existing = this._items.find((ci) => ci.item.id === item.id);
    if (existing) existing.quantity += qty;
    else this._items.push({ item, quantity: qty });
  }

  remove(itemId: string) {
    this._items = this._items.filter((ci) => ci.item.id !== itemId);
  }

  setQuantity(itemId: string, qty: number) {
    this._items = this._items
      .map((ci) => (ci.item.id === itemId ? { ...ci, quantity: Math.max(1, qty) } : ci))
      .filter((ci) => ci.quantity > 0);
  }

  clear() {
    this._items = [];
  }

  get count() {
    return this._items.reduce((acc, ci) => acc + ci.quantity, 0);
  }

  get total() {
    return this._items.reduce((acc, ci) => acc + ci.quantity * ci.item.price, 0);
  }
}

interface CartContextValue {
  service: CartService;
  items: CartItem[];
  count: number;
  total: number;
  refresh: () => void;
}

const CartContext = createContext<CartContextValue | null>(null);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [version, setVersion] = useState(0);
  const service = useMemo(() => new CartService(), []);
  const refresh = () => setVersion((v) => v + 1);
  const value = useMemo(
    () => ({ service, items: service.items, count: service.count, total: service.total, refresh }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [version, service],
  );
  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used within CartProvider");
  return ctx;
}
