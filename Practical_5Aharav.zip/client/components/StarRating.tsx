import { cn } from "@/lib/utils";

export function starRatingPipe(value: number, max = 5): string {
  const clamped = Math.max(0, Math.min(max, value));
  const full = Math.floor(clamped);
  const half = clamped - full >= 0.5 ? 1 : 0;
  return "★".repeat(full) + (half ? "½" : "") + "☆".repeat(max - full - half);
}

export function StarRating({ value, className }: { value: number; className?: string }) {
  const max = 5;
  const clamped = Math.max(0, Math.min(max, value));
  const full = Math.floor(clamped);
  const half = clamped - full >= 0.5;
  return (
    <div className={cn("flex items-center gap-0.5 text-amber-500", className)} aria-label={`Rating ${value} of 5`}>
      {Array.from({ length: max }).map((_, i) => {
        const filled = i < full;
        const isHalf = i === full && half;
        return (
          <span key={i} className={cn("text-lg leading-none", filled || isHalf ? "opacity-100" : "opacity-30")}>
            {isHalf ? "⯨" : "★"}
          </span>
        );
      })}
      <span className="ml-2 text-xs text-muted-foreground">{value.toFixed(1)}</span>
    </div>
  );
}
