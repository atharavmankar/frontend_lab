import { useQuery } from "@tanstack/react-query";
import { http } from "@/services/HttpClient";
import type { ListRestaurantsResponse, Restaurant } from "@shared/api";
import { Link } from "react-router-dom";
import { StarRating } from "./StarRating";
import { Button } from "@/components/ui/button";

function RestaurantCard({ r }: { r: Restaurant }) {
  const dollars = "$".repeat(r.priceLevel);
  return (
    <Link to={`/restaurant/${r.id}`} className="group block overflow-hidden rounded-xl border bg-card shadow-sm">
      <div className="relative h-40 w-full overflow-hidden">
        <img src={r.image} alt={r.name} className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105" />
        <div className="absolute bottom-2 left-2 rounded-md bg-black/55 px-2 py-1 text-xs text-white backdrop-blur-sm">
          {r.deliveryTimeMins} min • {r.cuisine} • {dollars}
        </div>
      </div>
      <div className="p-4">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-semibold">{r.name}</h3>
          <StarRating value={r.rating} />
        </div>
        <Button className="mt-3 w-full" variant="secondary">View Menu</Button>
      </div>
    </Link>
  );
}

export default function RestaurantListComponent() {
  const { data, isLoading, error } = useQuery({
    queryKey: ["restaurants"],
    queryFn: async () => await http.get<ListRestaurantsResponse>("/restaurants"),
  });

  if (isLoading) return <div className="py-20 text-center text-muted-foreground">Loading restaurants…</div>;
  if (error) return <div className="py-20 text-center text-destructive">Failed to load restaurants.</div>;

  const restaurants = data?.restaurants ?? [];

  return (
    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
      {restaurants.map((r) => (
        <RestaurantCard key={r.id} r={r} />
      ))}
    </div>
  );
}
