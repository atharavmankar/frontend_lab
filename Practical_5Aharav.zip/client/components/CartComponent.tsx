import { Button } from "@/components/ui/button";
import { useCart } from "@/services/CartService";

export default function CartComponent() {
  const { items, total, service, refresh } = useCart();
  return (
    <div className="sticky top-4 rounded-xl border bg-card p-4 shadow-sm">
      <div className="flex items-center justify-between">
        <h3 className="text-base font-semibold">Your Cart</h3>
        <span className="text-sm text-muted-foreground">{items.length} items</span>
      </div>
      <div className="mt-3 space-y-3">
        {items.length === 0 && (
          <p className="text-sm text-muted-foreground">Your cart is empty.</p>
        )}
        {items.map((ci) => (
          <div key={ci.item.id} className="flex items-center justify-between gap-2">
            <div>
              <p className="text-sm font-medium leading-tight">{ci.item.name}</p>
              <p className="text-xs text-muted-foreground">${ci.item.price.toFixed(2)}</p>
            </div>
            <div className="flex items-center gap-2">
              <Button size="sm" variant="outline" onClick={() => { service.setQuantity(ci.item.id, ci.quantity - 1); refresh(); }}>–</Button>
              <span className="w-6 text-center text-sm">{ci.quantity}</span>
              <Button size="sm" variant="outline" onClick={() => { service.setQuantity(ci.item.id, ci.quantity + 1); refresh(); }}>+</Button>
              <Button size="sm" variant="ghost" onClick={() => { service.remove(ci.item.id); refresh(); }}>Remove</Button>
            </div>
          </div>
        ))}
      </div>
      <div className="mt-4 flex items-center justify-between border-t pt-3">
        <span className="text-sm font-medium">Total</span>
        <span className="text-base font-semibold">${total.toFixed(2)}</span>
      </div>
      <Button className="mt-3 w-full" disabled={items.length === 0}>Checkout</Button>
    </div>
  );
}
