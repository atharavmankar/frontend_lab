import { useQuery } from "@tanstack/react-query";
import { http } from "@/services/HttpClient";
import type { ListMenuItemsResponse, MenuItem } from "@shared/api";
import { HotDealHighlight } from "@/directives/HotDealHighlight";
import { Button } from "@/components/ui/button";
import { useCart } from "@/services/CartService";

function MenuCard({ item, onAdd }: { item: MenuItem; onAdd: (item: MenuItem) => void }) {
  return (
    <HotDealHighlight isHotDeal={item.isHotDeal} className="h-full">
      <div className="flex gap-4">
        <img src={item.image} alt={item.name} className="h-24 w-24 rounded-md object-cover" />
        <div className="flex flex-1 flex-col">
          <div className="flex items-start justify-between gap-2">
            <h4 className="text-sm font-semibold">{item.name}</h4>
            <span className="text-sm font-medium">${item.price.toFixed(2)}</span>
          </div>
          <p className="mt-1 truncate text-xs text-muted-foreground">{item.description}</p>
          <div className="mt-auto pt-3">
            <Button size="sm" onClick={() => onAdd(item)}>
              Add to Cart
            </Button>
          </div>
        </div>
      </div>
    </HotDealHighlight>
  );
}

export default function MenuComponent({ restaurantId }: { restaurantId: string }) {
  const { service, refresh } = useCart();
  const { data, isLoading, error } = useQuery({
    queryKey: ["menu", restaurantId],
    queryFn: async () => await http.get<ListMenuItemsResponse>(`/restaurants/${restaurantId}/menu`),
  });

  const onAdd = (item: MenuItem) => {
    service.add(item, 1);
    refresh();
  };

  if (isLoading) return <div className="py-10 text-center text-muted-foreground">Loading menu…</div>;
  if (error) return <div className="py-10 text-center text-destructive">Failed to load menu.</div>;

  const items = data?.items ?? [];
  return (
    <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
      {items.map((item) => (
        <MenuCard key={item.id} item={item} onAdd={onAdd} />
      ))}
    </div>
  );
}
