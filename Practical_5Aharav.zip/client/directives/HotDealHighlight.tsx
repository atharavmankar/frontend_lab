import { cn } from "@/lib/utils";

export function HotDealHighlight({
  isHotDeal,
  children,
  className,
}: {
  isHotDeal?: boolean;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "relative rounded-lg border bg-card p-4 shadow-sm transition-all",
        isHotDeal
          ? "ring-2 ring-rose-500/40 border-rose-200 bg-gradient-to-br from-rose-50 to-transparent"
          : "",
        className,
      )}
    >
      {isHotDeal && (
        <span className="absolute -top-2 -right-2 select-none rounded-full bg-rose-600 px-2 py-1 text-[10px] font-bold uppercase tracking-widest text-white shadow-sm">
          Hot Deal
        </span>
      )}
      {children}
    </div>
  );
}
