import { useParams, Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { http } from "@/services/HttpClient";
import type { GetRestaurantResponse } from "@shared/api";
import MenuComponent from "@/components/MenuComponent";
import CartComponent from "@/components/CartComponent";
import { Button } from "@/components/ui/button";
import { StarRating } from "@/components/StarRating";

export default function RestaurantDetails() {
  const params = useParams();
  const id = params.id as string;
  const { data, isLoading, error } = useQuery({
    queryKey: ["restaurant", id],
    queryFn: async () => await http.get<GetRestaurantResponse>(`/restaurants/${id}`),
  });

  if (isLoading) return <div className="py-20 text-center text-muted-foreground">Loading…</div>;
  if (error || !data?.restaurant)
    return (
      <div className="container mx-auto px-4 py-10 text-center">
        <p className="text-destructive">Restaurant not found.</p>
        <Button asChild className="mt-4">
          <Link to="/">Back to Home</Link>
        </Button>
      </div>
    );

  const r = data.restaurant;

  return (
    <div className="container mx-auto grid grid-cols-1 gap-8 px-4 py-8 lg:grid-cols-3">
      <div className="lg:col-span-2">
        <div className="overflow-hidden rounded-2xl border bg-card shadow-sm">
          <img src={r.image} alt={r.name} className="h-56 w-full object-cover" />
          <div className="p-6">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h1 className="text-2xl font-extrabold">{r.name}</h1>
                <p className="text-sm text-muted-foreground">{r.cuisine} • {"$".repeat(r.priceLevel)} • {r.deliveryTimeMins} min</p>
              </div>
              <StarRating value={r.rating} />
            </div>
          </div>
        </div>
        <div className="mt-6">
          <h2 className="mb-3 text-lg font-bold">Menu</h2>
          <MenuComponent restaurantId={r.id} />
        </div>
      </div>
      <aside className="lg:col-span-1">
        <CartComponent />
      </aside>
    </div>
  );
}
