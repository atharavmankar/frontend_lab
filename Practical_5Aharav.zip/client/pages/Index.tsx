import RestaurantListComponent from "@/components/RestaurantListComponent";
import { Button } from "@/components/ui/button";

export default function Index() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-rose-50 to-white">
      <section className="container mx-auto px-4 py-10">
        <div className="rounded-2xl bg-gradient-to-r from-rose-600 to-orange-500 p-10 text-white shadow-lg">
          <h1 className="text-3xl font-extrabold tracking-tight sm:text-4xl">Crave it. Tap it. Eat happy.</h1>
          <p className="mt-2 max-w-xl text-white/90">Discover top-rated restaurants near you and get your favorites delivered fast.</p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Button size="lg" variant="secondary">Browse Restaurants</Button>
            <Button size="lg" variant="outline" className="bg-white/10 text-white hover:bg-white/20">View Hot Deals</Button>
          </div>
        </div>
      </section>
      <section className="container mx-auto px-4 pb-16">
        <h2 className="mb-4 text-xl font-bold">Popular Restaurants</h2>
        <RestaurantListComponent />
      </section>
    </div>
  );
}
