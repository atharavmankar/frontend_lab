/**
 * Shared code between client and server
 * Useful to share types between client and server
 * and/or small pure JS functions that can be used on both client and server
 */

/**
 * Example response type for /api/demo
 */
export interface DemoResponse {
  message: string;
}

// Food Delivery domain types
export interface Restaurant {
  id: string;
  name: string;
  cuisine: string;
  rating: number; // 0-5
  deliveryTimeMins: number;
  image: string;
  priceLevel: 1 | 2 | 3 | 4; // $ to $$$$
}

export interface MenuItem {
  id: string;
  restaurantId: string;
  name: string;
  description: string;
  price: number; // in USD
  image: string;
  isHotDeal?: boolean; // highlighted by custom directive
}

export interface CartItem {
  item: MenuItem;
  quantity: number;
}

// API response shapes
export interface ListRestaurantsResponse {
  restaurants: Restaurant[];
}

export interface GetRestaurantResponse {
  restaurant: Restaurant | null;
}

export interface ListMenuItemsResponse {
  items: MenuItem[];
}
