import { RequestHandler } from "express";
import fs from "fs";
import path from "path";
import {
  ListRestaurantsResponse,
  GetRestaurantResponse,
  ListMenuItemsResponse,
  Restaurant,
  MenuItem,
} from "@shared/api";

interface DbShape {
  restaurants: Restaurant[];
  menuItems: MenuItem[];
}

const dbPath = path.resolve(process.cwd(), "db.json");

function readDb(): DbShape {
  try {
    const raw = fs.readFileSync(dbPath, "utf-8");
    const data = JSON.parse(raw) as DbShape;
    return data;
  } catch (e) {
    return { restaurants: [], menuItems: [] };
  }
}

export const handleListRestaurants: RequestHandler = (_req, res) => {
  const { restaurants } = readDb();
  const response: ListRestaurantsResponse = { restaurants };
  res.status(200).json(response);
};

export const handleGetRestaurant: RequestHandler = (req, res) => {
  const { id } = req.params as { id: string };
  const { restaurants } = readDb();
  const restaurant = restaurants.find((r) => r.id === id) ?? null;
  const response: GetRestaurantResponse = { restaurant };
  if (!restaurant) return res.status(404).json(response);
  res.status(200).json(response);
};

export const handleListMenuItems: RequestHandler = (req, res) => {
  const { id } = req.params as { id: string };
  const { menuItems } = readDb();
  const items = menuItems.filter((i) => i.restaurantId === id);
  const response: ListMenuItemsResponse = { items };
  res.status(200).json(response);
};
